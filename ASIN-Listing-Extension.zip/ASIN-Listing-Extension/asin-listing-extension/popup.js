// ASIN Listing Generator - popup logic
const MODEL = "gemini-2.5-flash";
const DELAY_MS = 800;
const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;

const $ = (id) => document.getElementById(id);
const els = {
  apiKey: $("apiKey"), file: $("file"), mapping: $("mapping"), status: $("status"),
  start: $("start"), stop: $("stop"), download: $("download"),
};

let headers = [];
let rows = [];          // all rows including header (array of arrays)
let cols = { sku: -1, asin: -1, image: -1 };
let results = {};       // rowIndex -> { title, description, bullets, imageUsed } | { error }
let stopRequested = false;
let running = false;

// ---------- helpers ----------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const setStatus = (msg) => { els.status.textContent = msg; };

function loadKey() {
  try { els.apiKey.value = localStorage.getItem("geminiKey") || ""; } catch (_) {}
}
els.apiKey.addEventListener("change", () => {
  try { localStorage.setItem("geminiKey", els.apiKey.value.trim()); } catch (_) {}
  updateButtons();
});

function findCol(re) {
  return headers.findIndex((h) => re.test(h));
}

function updateButtons() {
  els.start.disabled = running || !rows.length || !els.apiKey.value.trim();
  els.stop.disabled = !running;
  els.download.disabled = running || !Object.keys(results).length;
}

// ---------- file upload ----------
els.file.addEventListener("change", async () => {
  const file = els.file.files[0];
  if (!file) return;
  results = {};
  try {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
    headers = (rows[0] || []).map((h) => String(h).trim());

    cols.sku = findCol(/sku/i);
    cols.asin = findCol(/asin/i);
    cols.image = findCol(/image|img|photo/i);
    if (cols.sku < 0) cols.sku = 0;

    els.mapping.textContent =
      `SKU: ${headers[cols.sku]} | Image: ${cols.image >= 0 ? headers[cols.image] : "nahi mila (text-only)"} | Rows: ${rows.length - 1}`;
    setStatus("File load ho gayi. Generate dabayein.");
  } catch (e) {
    setStatus("File read error: " + e.message);
  }
  updateButtons();
});

// ---------- image fetch ----------
async function fetchImage(url) {
  if (!url || !/^https?:\/\//i.test(url)) return null;
  try {
    const r = await fetch(url);
    if (!r.ok) return null;
    const type = (r.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (!IMAGE_TYPES.includes(type)) return null;
    const blob = await r.blob();
    if (blob.size > MAX_IMAGE_BYTES) return null;
    const dataUrl = await new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.onerror = reject;
      fr.readAsDataURL(blob);
    });
    return { media_type: type, data: String(dataUrl).split(",")[1] };
  } catch (_) {
    return null; // image fetch fail -> text-only fallback
  }
}

// ---------- prompt + API ----------
function buildPrompt(sku, hasImage) {
  return `You are an Amazon listing copywriter.

Product info:
- Product SKU: ${sku}
${hasImage
    ? "- The product image is attached. Base product type, features and colors on what you can see in the image."
    : "- No image is available. Infer carefully from the SKU name and do not invent specific specs."}

Write the listing in English. Return ONLY valid JSON, no markdown, in this exact shape:
{"title": "...", "description": "...", "bullets": ["...", "...", "...", "...", "...", "...", "...", "..."]}

Rules:
- title: max 200 characters, keyword-rich, no emoji, no ALL CAPS words.
- description: 150-250 words, persuasive, plain text, no emoji.
- bullets: exactly 8 items. Each starts with ONE relevant emoji, then a space, then a short BENEFIT IN CAPS heading, then a colon and a clear benefit sentence. Max 250 characters each.
- Do not invent certifications, warranty or exact measurements you cannot verify.`;
}

async function generateListing(sku, image) {
  const key = els.apiKey.value.trim();
  const parts = [];
  if (image) parts.push({ inline_data: { mime_type: image.media_type, data: image.data } });
  parts.push({ text: buildPrompt(sku, !!image) });

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "x-goog-api-key": key,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      contents: [{ role: "user", parts }],
      generationConfig: {
        responseMimeType: "application/json",
        maxOutputTokens: 1500,
      },
    }),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`Gemini API ${res.status}: ${t.slice(0, 150)}`);
  }
  const data = await res.json();
  const cand = (data.candidates || [])[0];
  const text = ((cand && cand.content && cand.content.parts) || []).map((p) => p.text || "").join("");
  const s = text.indexOf("{");
  const e = text.lastIndexOf("}");
  if (s < 0 || e < 0) throw new Error("JSON nahi mila in response");
  const obj = JSON.parse(text.slice(s, e + 1));
  const bullets = Array.isArray(obj.bullets) ? obj.bullets.slice(0, 8) : [];
  while (bullets.length < 8) bullets.push("");
  return { title: obj.title || "", description: obj.description || "", bullets, imageUsed: !!image };
}

// ---------- main loop ----------
els.start.addEventListener("click", async () => {
  running = true;
  stopRequested = false;
  updateButtons();
  results = {};

  const dataRows = [];
  for (let i = 1; i < rows.length; i++) {
    const sku = String(rows[i][cols.sku] || "").trim();
    if (sku) dataRows.push(i);
  }

  let done = 0, errors = 0;
  for (const i of dataRows) {
    if (stopRequested) break;
    const row = rows[i];
    const sku = String(row[cols.sku] || "").trim();
    setStatus(`Processing ${done + 1}/${dataRows.length}: ${sku}`);
    try {
      const image = cols.image >= 0 ? await fetchImage(String(row[cols.image] || "").trim()) : null;
      results[i] = await generateListing(sku, image);
    } catch (e) {
      results[i] = { error: e.message };
      errors++;
    }
    done++;
    await sleep(DELAY_MS);
  }

  running = false;
  setStatus(`${stopRequested ? "Stop kiya. " : ""}Done: ${done}/${dataRows.length}, errors: ${errors}.\nDownload button se Excel lein.`);
  updateButtons();
});

els.stop.addEventListener("click", () => {
  stopRequested = true;
  setStatus("Current row ke baad ruk jayega...");
});

// ---------- download ----------
els.download.addEventListener("click", () => {
  const bulletHeaders = Array.from({ length: 8 }, (_, k) => `Bullet ${k + 1}`);
  const outHeaders = [...headers, "Generated Title", "Generated Description", ...bulletHeaders, "Status"];
  const out = [outHeaders];

  for (let i = 1; i < rows.length; i++) {
    const base = [...rows[i]];
    while (base.length < headers.length) base.push("");
    const r = results[i];
    if (!r) {
      out.push([...base]);
    } else if (r.error) {
      out.push([...base, "", "", ...Array(8).fill(""), "ERROR: " + r.error]);
    } else {
      out.push([
        ...base, r.title, r.description, ...r.bullets,
        r.imageUsed ? "OK" : "OK (text-only, image nahi mili)",
      ]);
    }
  }

  const ws = XLSX.utils.aoa_to_sheet(out);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Listings");
  // Build the file in memory and trigger a real browser download.
  const bytes = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "listings_output.xlsx";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setStatus("Excel download shuru ho gaya: listings_output.xlsx");
});

loadKey();
updateButtons();
